// Booking model (CommonJS)
module.exports = {
  // ...model definition...
};