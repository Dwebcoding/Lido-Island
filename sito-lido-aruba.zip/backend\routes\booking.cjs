// Booking route (CommonJS)
module.exports = function(app) {
  // ...route definition...
};