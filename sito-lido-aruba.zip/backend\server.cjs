// Main server (CommonJS)
const express = require('express');
const app = express();
// ...server setup...
module.exports = app;