// Database config (CommonJS)
module.exports = {
  sqlitePath: '../database.sqlite',
};