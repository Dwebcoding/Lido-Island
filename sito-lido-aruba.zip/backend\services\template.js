// Email template (ESM)
export default {
  // ...template logic...
};