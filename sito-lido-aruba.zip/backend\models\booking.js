// Booking model (ESM)
export default {
  // ...model definition...
};