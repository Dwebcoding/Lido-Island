// Email template (CommonJS)
module.exports = {
  // ...template logic...
};