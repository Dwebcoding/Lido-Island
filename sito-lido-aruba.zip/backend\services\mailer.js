// Mailer service (ESM)
export default {
  // ...mailer logic...
};