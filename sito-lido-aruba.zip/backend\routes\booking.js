// Booking route (ESM)
export default function(app) {
  // ...route definition...
};