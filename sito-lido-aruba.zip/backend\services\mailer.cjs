// Mailer service (CommonJS)
module.exports = {
  // ...mailer logic...
};