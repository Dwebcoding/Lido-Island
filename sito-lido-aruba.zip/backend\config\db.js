// Database config (ESM)
export const sqlitePath = '../database.sqlite';